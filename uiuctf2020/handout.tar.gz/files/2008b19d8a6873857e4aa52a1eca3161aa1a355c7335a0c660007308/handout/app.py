from flask import Flask, session, request, make_response
import yaml
import re
import os

app = Flask(__name__)
app.secret_key = os.urandom(16)

@app.route('/', methods=["POST"])
def pwnme():
    if not re.fullmatch(b"^[\n --/-\]a-}]*$", request.data, flags=re.MULTILINE):
        return "Nice try!", 400
    return yaml.load(request.data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
