<?php

namespace App\Controller;

use App\Entity\User;
use App\Security\LoginFormAuthenticator;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use Symfony\Component\Security\Guard\GuardAuthenticatorHandler;

class AccountsController extends AbstractController
{
    /**
     * @Route("/register", name="app_register")
     */
    public function register(Request $request,UserPasswordEncoderInterface $passwordmanager,EntityManagerInterface $em,GuardAuthenticatorHandler $guard,LoginFormAuthenticator $loginFormAuthenticator)
    {
        if ($request->getMethod()==="POST"){
            if($request->request->get("username")&& $request->request->get("password")){
                try {


                    $user = new User();
                    $user->setUsername($request->request->get("username"));
                    $user->setPassword($passwordmanager->encodePassword($user, $request->request->get("password")));
                    $em->persist($user);
                    $em->flush();
                    return $guard->authenticateUserAndHandleSuccess($user, $request, $loginFormAuthenticator, 'main');
                }
                catch (UniqueConstraintViolationException $exception){
                    return $this->render("accounts/register.html.twig",["error"=>"This username already exists"]);
                }
            }
            return $this->render("accounts/register.html.twig",["error"=>null]);

        }
        return $this->render("accounts/register.html.twig",["error"=>null]);
    }

        /**
         * @Route("/account",name="app_account")
         * @IsGranted("ROLE_USER")
         */
    public function account(){
        return $this->render('accounts/account.html.twig');
    }
}
