<?php


namespace App\Controller;

use App\Entity\Jutsus;
use App\Entity\User;
use App\Service\Curl;
use Doctrine\ORM\EntityManagerInterface;
use Knp\Bundle\MarkdownBundle\MarkdownParserInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * Class JutsusController
 * @package App\Controller
 * @IsGranted("ROLE_USER")
 */
class JutsusController extends \Symfony\Bundle\FrameworkBundle\Controller\AbstractController
{
    /**
     * @Route("/new-jutsu",name="app_newjutsu")
     */
    public function addJutsu(Request $request,EntityManagerInterface $em){
        if ($request->getMethod()==="POST"){
            if ($request->request->get("name") && $request->request->get("description")){
                $jutsu=new Jutsus();
                $jutsu->setName($request->request->get("name"));
                $jutsu->setDescription($request->request->get("description"));
                $jutsu->setPublishedAt(new \DateTime());
                $jutsu->setUser($this->getUser());
                $em->persist($jutsu);
                $em->flush($jutsu);
                $id=$jutsu->getId();
                return $this->redirect("/jutsu/$id");
            }
            return $this->render("jutsus/new.html.twig");
        }
        return $this->render("jutsus/new.html.twig");
    }
    /**
     * @Route("/jutsu/{id<\d+>}",name="app_viewjutsu")
     */
public function viewJutsu($id,EntityManagerInterface $em,CacheInterface $cache,MarkdownParserInterface $markdown){
        $repo=$em->getRepository(Jutsus::class);
        $jutsu=$repo->findOneBy(["id"=>$id]);
        $this->denyAccessUnlessGranted("SHOW",$jutsu);
        //fetch jutsu + htmlspecialchars+markdown
        $name=$jutsu->getName();
        $desc=htmlspecialchars($jutsu->getDescription());
        $description=$cache->get("jutsu".$jutsu->getId(),function()use($markdown,$desc){
            return $markdown->transformMarkdown($desc);
        });
        $publishedAt=$jutsu->getPublishedAt()->format('Y-m-d H:i:s');
        $author=$jutsu->getUser();
        return $this->render("jutsus/show.html.twig",["name"=>$name,"description"=>$description,"publishedAt"=>$publishedAt,"author"=>$author]);
}

    /**
     * @Route("/all",name="app_alljutsu")
     */
public function allJutsus(){
    $jutsus=$this->getUser()->getJutsus();
    return $this->render("jutsus/all.html.twig",["jutsus"=>$jutsus]);
}
    /**
     * @Route("/autojutsu",name="app_addauto")
     */
    public function addAutoJutsu(Request $request,Curl $curl,EntityManagerInterface $em){
        if($request->getMethod()==="POST"){
            if($request->get("url")){
                $url=$request->get("url");
                if(preg_match('/file|db|localhost|127.0.0.1|dir|dbfilename|flush/i',$url)){
                    return $this->render("jutsus/error.html.twig");
                }
                    $title = $curl->extractTitle($url);
                    $response = $curl->fetch($url);
                    $jutsu = new Jutsus();
                    $jutsu->setUser($this->getUser())
                        ->setPublishedAt(new \DateTime())
                        ->setName($title)
                        ->setDescription($response);
                    $em->persist($jutsu);
                    $em->flush();
                    $id = $jutsu->getId();
                    return $this->redirect("/jutsu/$id");

            }
        }
        else{
            return $this->render("jutsus/fetcher.html.twig");
        }
    }
    /**
     * @Route("/report-admin",name="app_report")
     */
    public function reportAdmin(Request $request,HttpClientInterface $client){
        if($request->getMethod()==="POST"){
            if($request->get("url")){
                $url=$request->get("url");
                if(preg_match("/^http:\/\/web1.fword.wtf\/jutsu\/\d*$/x",$url)){
                    try {
                        $response = $client->request("GET", "http://api/?url=".$url, ['timeout' => 10])->getContent();
                    } catch (\Exception $e){
                        $response="success";
                    }
                    if($response==="success"){
                        return $this->render("jutsus/report.html.twig",["result"=>"Admin has visited your jutsu successfully"]);
                    }
                    else{
                        return $this->render("jutsus/report.html.twig",["result"=>"An error has occured"]);
                    }
                }
                else {
                    return $this->render("jutsus/report.html.twig",["result"=>"Please provide a valid jutsu url"]);
                }
            }
            else{
                return $this->render("jutsus/report.html.twig",["result"=>"Please enter a url"]);
            }
        }
        else{
            return $this->render("jutsus/report.html.twig",["result"=>""]);
        }
    }
}

