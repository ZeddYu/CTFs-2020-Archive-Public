<?php

namespace App\Repository;

use App\Entity\Jutsus;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Jutsus|null find($id, $lockMode = null, $lockVersion = null)
 * @method Jutsus|null findOneBy(array $criteria, array $orderBy = null)
 * @method Jutsus[]    findAll()
 * @method Jutsus[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class JutsusRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Jutsus::class);
    }

    // /**
    //  * @return Jutsus[] Returns an array of Jutsus objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('j')
            ->andWhere('j.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('j.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Jutsus
    {
        return $this->createQueryBuilder('j')
            ->andWhere('j.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
