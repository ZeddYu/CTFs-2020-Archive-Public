<?php


namespace App\Service;


class Curl
{
    public function fetch(string $url):string {
        $response = shell_exec("curl '".escapeshellcmd($url)."' -s --max-time 6");
        preg_replace('/<title>(.*)<\/title>/i','',$response);
        return (!empty($response)?substr($response,0,780):"");

    }
    public function extractTitle(string $url):string{
        $response=$this->fetch($url);
        $output=array();
        preg_match('/<title>(.*)<\/title>/i',$response,$output);
        return (array_key_exists(1,$output) ? $output[1]:"Unknown Jutsu");

    }
}