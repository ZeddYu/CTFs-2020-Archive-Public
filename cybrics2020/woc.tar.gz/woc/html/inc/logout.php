<?php
unset($_SESSION['userid'], $_SESSION['username']);
redir(".");
