#!/bin/sh

python /app/app.py
